"""
Golden Validation - Tithi
"""

from datetime import datetime

from src.astrology.tithi import TithiEngine
from src.services.chart_builder import ChartBuilder
from src.validation.csv_reader import CsvReader
from src.validation.framework.validator import Validator


LATITUDE = 28.6139
LONGITUDE = 77.2090


def main():

    validator = Validator("Tithi")

    rows = CsvReader.read(
        "src/validation/tithi/tithi_golden.csv"
    )

    for row in rows:

        timestamp = datetime.fromisoformat(
            row["timestamp"]
        )

        chart = ChartBuilder.build(
            timestamp,
            LATITUDE,
            LONGITUDE,
        )

        result = TithiEngine.calculate(chart)

        validator.compare(
            int(row["tithi_number"]),
            result.number,
        )

    validator.finish()


if __name__ == "__main__":
    main()