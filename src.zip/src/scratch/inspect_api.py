import swisseph as swe

print("Version:", swe.version)
print()

help(swe.rise_trans)